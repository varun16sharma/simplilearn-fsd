let quiz=[
    {
        question:"Which of the following JavaScript cannot do?",
        option:[
            "1.JavaScript can react to events",
            "2.JavaScript can manipulate HTML elements",
            "3.JavaScript can be use to validate data",
            "4.All of the Above",
        ],
        answer:4,
    },
    {
        question:" _________ keyword is used to declare variables in javascript.",
        option:[
            "1.Var",
            "2.Dim",
            "3.String",
            "4.None of the Above",
            
        ],
        answer:1,
    },
    {
        question:"In JavaScript the x===y statement implies that:",
        option:[
            "1.Both x and y are equal in value, type and reference address as well.",
            "2.Both are x and y are equal in value only.",
            "3.Both are equal in the value and data type.",
           "4.Both are not same at all.",   
        ],
        answer:3,
    },
    {
        question:"Whats so great about XML?",
        option:[
            "1.Easy data exchange",
            "2.High speed on network ",
            "3.Both",
            "4.None",   
        ],
        answer:3,

    },
    {
        question:"In the JavaScript, which one of the following is not considered as an error:",
        option:[
            "1.Syntax error",
            "2.Missing of semicolons",
            "3.Division by zero",
            "4.Missing of Bracket",   
        ],
        answer:3,
    }
]